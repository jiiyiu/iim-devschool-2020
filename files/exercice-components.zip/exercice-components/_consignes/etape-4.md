De la même manière que l'on peut utiliser `v-for` sur une balise HTML, il est possible d'itérer sur un composant :

```html
<!-- Ce composant sera répété autant de fois qu'il y a d'objets "obj" dans la data "tableau" -->
<mon-super-composant v-for="obj in tableau"></mon-super-composant>
```

On peut également toujours passer des _props_ à ce composant :

```html
<mon-super-composant v-for="objet in monTableau" v-bind:valeur1="objet.valeur1" v-bind:valeur2="objet.valeur2"></mon-super-composant>
```

# Consignes

Dans le fichier `_static/person-data.json` se trouve (toujours) un tableau de 5 personnes.

1. Importez ce tableau dans le modèle de données (`data`) de l'instance de Vue.js

2. Dans la partie HTML, retirez les 5 appels au composant `person` pour n'en garder qu'un, et répètez-le avec la directive `v-for`

Il faudra faire attention à `v-bind` les valeurs des 4 props (qui seront maintenant des variables)
