# Consigne

Dans le HTML, faites 5 appels au composant `person` précédemment créé
