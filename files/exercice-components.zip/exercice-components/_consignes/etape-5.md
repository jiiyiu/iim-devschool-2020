Passer l'ensemble des propriétés d'un objet à un composant une par une peut devenir long et fastidieux :

```html
    <mon-super-composant :proprieteA="monObjet.valeurA" :proprieteB="monObjet.valeurB" :proprieteC="monObjet.valeurC" :proprieteD="monObjet.valeurD" … ></mon-super-composant>
```

Il est donc possible, et parfois préférable, de passer l'intégralité de l'objet en tant que _props_ d'un composant :

```html
    <mon-super-composant :objet="monObjet"></mon-super-composant>
```

Ici, la _props_ `objet` reçoit en interne la valeur de `monObjet` qui contient toutes les propriétés nécessaires au composant.

# Consignes

1. Dans le JS, modifiez la définition du composant `person` pour qu'il n'accepte qu'une seule prop du nom de `person` (soit le même nom que le composant lui-même)

2. Toujours dans le JS, adaptez la partie `template` pour l'affichage des variables (qui proviennent maintenant de l'objet `person`)

3. Dans le HTML, retirez les 4 props `firstname`, `lastname`, `description` et `photo` et passez à votre composant l'objet `person` sur lequel vous bouclez.

L'idée serait d'obtenir quelque-chose comme ceci :

```html
<person v-for="objet in monTableau" :person="objet">
```