Un composant personnalisé peut recevoir des _propriétés_, appelées dans Vue.js des _props_

Les props doivent êtres explicitement déclarées lors de l'enregistrement du composant, en précisant leur nom et nature :

```js
Vue.component('mon-super-composant', {
    props : {
        prop1 : String,
        prop2 : Number,
        /* ... */
    },
    template : `Valeur de prop1 : {{prop1}}
                Valeur de prop2 : {{prop2}}`
})
```

Côté HTML, il on le renseigne à la manière d'un attribut sur une balise :

```js
<mon-super-composant prop1="Chaîne de caractère" prop2="42"></mon-super-composant>
```

# Consignes

1. Modifiez côté JS la définition composant `person` afin qu'il puisse accepter 4 props (qui sont toutes des String) :
    - `firstname`
    - `lastname`
    - `description`
    - `photo`

Dans le fichier `_static/person-data.json` se trouvent des informations sur 5 personnes.

2. Placez manuellement ces informations sur les _props_ des 5 composants créés précédemment

N'oubliez pas non plus de modifier la partie `template` du composant pour y afficher la valeur des props.
