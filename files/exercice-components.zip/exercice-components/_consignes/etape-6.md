Un composant reçoit des _props_ et fait remonter des _événements_ à son parent. Il s'agit du cycle de communication des données dans Vue.js.

Un composant peut en interne émettre un événement grâce à la fonction Vue.js `this.$emit(<eventName>, …<arguments>)`

# Consignes

1. Dans le `template` de votre composant `person`, il y a une balise `<button>` commentée. Décommentez-là pour faire apparaître un bouton 'fab'.

2. Inscrivez sur ce bouton l'événement `click` avec la dictive `v-on` (ou son raccourci `@`) en faisant appel à une méthode que vous nommerez `clickDelete`.

3. Toujours dans la définition du composant `person`, créez cette méthode :

Grâce à la fonction `this.$emit()` de Vue.js, faites en sorte que votre méthode émette un événement du nom de `remove-event` au parent, en lui passant l'objet `person` reçu en _props_

4. Dans le fichier `index.html` à l'endroit où vous appelez le composant `<person …>`, ajoutez-lui l'événement précédemment nommé `remove-event` avec la directive `v-on` en faisant appel à une méthode que vous nommerez `removePerson`.

5. Dans l'instance de Vue cette fois (c'est à dire, dans le `new Vue(…)`), déclarez la méthode `removePerson` qui acceptera en argument l'objet `person` à supprimer, et supprimez-le du tableau `this.persons`
