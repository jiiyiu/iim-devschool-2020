Un composant Vue s'enregistre de deux manières :

Globale (toutes les instances) :

```js
Vue.component('mon-super-composant', {/* objet de configuration du composant */} );
```

Locale à l'instance:

```js
var monSuperComposant = {/* objet de configuration du composant */};

new Vue({
    /* ... */

    components : { 'mon-super-composant' : monSuperComposant }
});
```

Une fois ce composant connu de Vue.js, vous pouvez y faire appel dans le HTML sous forme de _balise_ : `<mon-super-composant></mon-super-composant>`

# Consignes

1. Enregistrez dans l'objet `Vue` un composant du nom de `person` (de manière _globale_)

Vous trouverez le template HTML d'une _card_ dans le fichier `_static/person-template.html`

2. Faites appel à ce composant dans la partie HTML
