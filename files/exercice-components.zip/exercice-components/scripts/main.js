(function() {
    'use strict';

    /*
        Enregistrez ici le composant nommé "person" de façon globale dans Vue
        ...
    */


    new Vue({
        el : '#app',

        data : function() {
            return {

            }
        }
    })
})();